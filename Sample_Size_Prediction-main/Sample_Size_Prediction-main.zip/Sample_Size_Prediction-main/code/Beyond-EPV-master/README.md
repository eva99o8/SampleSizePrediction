# Beyond-EPV
Simulation codes from "Beyond EPV" project


Code belonging to a paper published in Statistical Methods in Medical Research.
